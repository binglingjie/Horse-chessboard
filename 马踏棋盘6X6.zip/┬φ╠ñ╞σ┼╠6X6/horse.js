//������ 
var horse=new Array(2);
horse[0]=0;
horse[1]=0;

//��ʼλ��
var start_x=0;
var start_y=0; 

//��
var result; 

//��ͼ�С��� 
var ROW=6;
var COL=6;

var map=new Array(ROW);
for(var i=0;i<ROW;i++)
{
	map[i]=new Array(COL);
	for(var j=0;j<COL;j++)
	{
		map[i][j]=0;
	}
}

//�Ѿ��߹�λ����Ϣ���Ѿ��߹���λ�ø��� 
var count=0;
var position=new Array(ROW*COL);
for(var i=0;i<ROW*COL;i++)
{
	position[i]=new Array(2);
	position[i][0]=0;
	position[i][1]=0;
}

//�������������
function randHourse()
{
	horse[0]=Math.floor(Math.random()*ROW);
	horse[1]=Math.floor(Math.random()*COL);
} 

//����ROW*COL��div 
function createDiv()
{
	var center=document.createElement("center");
	document.body.appendChild(center);
	var table=document.createElement("table");
	center.appendChild(table);
	for(var i=0;i<ROW;i++)
	{
		var tr=document.createElement("tr");
		table.appendChild(tr);
		for(var j=0;j<COL;j++)
		{
			var td=document.createElement("td");
			tr.appendChild(td);
			var div=document.createElement("div");
			td.appendChild(div);
			div.id="div_"+i+"_"+j;
			div.innerHTML="";
		}
	}
}

//����div�����ݺ���ɫ
function initailizeDiv()
{
	for(var i=0;i<ROW;i++)
	{
		for(var j=0;j<COL;j++)
		{
			var div=document.getElementById("div_"+i+"_"+j);
			div.style.backgroundColor="lightblue";
		}
	}
} 

//�˻���һ��
function lastStep()
{
	if(count==1)
	{
		alert("you have return the first !");
		return;
	}
	document.getElementById("div_"+horse[0]+"_"+horse[1]).innerHTML="";
	initailizeDiv();
	count-=2;
	horse[0]=position[count][0];
	horse[1]=position[count][1];
	//alert(horse[0]+" "+horse[1]);
	hourseIntoDiv();
} 

document.onkeyup=function(){
	var e=event||window.event;
	//alert(e.keyCode);
	if(e.keyCode==80)
	{
		lastStep();
	}
	else if(e.keyCode==82)
	{
		//alert("r");
		openResult();
	}
}

function giveMsg()
{
	alert("the result you want is "+start_x+"_"+start_y+".txt");
}

function openResult()
{
	var file=document.getElementById("file");
    	count=0;
	var reader = new FileReader();//���Ǻ���,��ȡ���������������.
    	reader.readAsText(file.files[0]);//��ȡ�ļ�������,Ҳ���Զ�ȡ�ļ���URL
	reader.onload = function () {
        //����ȡ��ɺ�ص��������,Ȼ���ʱ�ļ������ݴ洢����result��,ֱ�Ӳ�������
        //console.log(this.result);
        //alert(this.result);
        result=this.result.split(" ");
        var m=0,n=0;
        for(var i=0;i<result.length;i++)
        {
        	var number=parseInt(parseInt(result[i]));
			if(number>=1) {
				map[m][n]=number;
				if(n==COL-1)
				{
					m++;
					if(m==ROW)
					{
						break;
					}
					n=0;
				}
				else
				{
					n++;
				}
			}
		}
		for(var i=0;i<ROW;i++)
		{
			for(var j=0;j<COL;j++)
			{
				document.getElementById("div_"+i+"_"+j).innerHTML="";
				document.getElementById("div_"+i+"_"+j).style.backgroundColor="lightwhite";
			}
		}
	    activeBySelf();
    }
}

//�ҵ�ǰҪ�µ�λ��
function getXY()
{
	for(var i=0;i<ROW;i++)
	{
		for(var j=0;j<COL;j++)
		{
			if(map[i][j]==count+1)
			{
				horse[0]=i;
				horse[1]=j;
				//alert(i+" "+j);
				return;
			}
		}
	}
} 

//�Զ����մ�̤����
function activeBySelf()
{
	//alert(map);
	var t=setInterval(function(){
		getXY();
		hourseIntoDiv();
		if(count==ROW*COL)
		{
			clearInterval(t);
		}
	},1000);
} 

//����div
function hourseIntoDiv()
{
	initailizeDiv();
	var div=document.getElementById("div_"+horse[0]+"_"+horse[1]);
	div.style.backgroundColor="white";
	position[count][0]=parseInt(horse[0]); 
	position[count][1]=parseInt(horse[1]);
	div.innerHTML=++count;
	showCanPass();
	if(count==ROW*COL)
	{
		alert("you are win !");
	}
	else if(!hasNoRoad())
	{
		alert("you run "+count+" steps !");
	}
} 

createDiv();

//�µ���Ϸ
function newGame()
{
	randHourse();
	start_x=horse[0];
	start_y=horse[1];
	hourseIntoDiv();
} 
newGame();

//��ʾ�����ߵĸ���
function showCanPass()
{
	for(var i=0;i<ROW;i++)
	{
		for(var j=0;j<COL;j++)
		{
			if((i-horse[0]==1||i-horse[0]==-1)&&(j-horse[1]==2||j-horse[1]==-2)||(i-horse[0]==2||i-horse[0]==-2)&&(j-horse[1]==1||j-horse[1]==-1))
			{
				var div=document.getElementById("div_"+i+"_"+j);
				if(div.innerHTML=="")
				{
					div.style.backgroundColor="pink";
				}
			}
		}
	}
} 

//��div���ӵ�������¼� 
document.addEventListener('click',function(){
	var event=event||window.event;
	var obj=document.elementFromPoint(event.clientX,event.clientY);
	if(obj.tagName=="DIV")
	{
		var msg=obj.id.split("_");
		var i=msg[1];
		var j=msg[2];
		if((i-horse[0]==1||i-horse[0]==-1)&&(j-horse[1]==2||j-horse[1]==-2)||(i-horse[0]==2||i-horse[0]==-2)&&(j-horse[1]==1||j-horse[1]==-1))
		{
			var div=document.getElementById("div_"+i+"_"+j);
			if(div.innerHTML=="")
			{
				horse[0]=parseInt(i);
				horse[1]=parseInt(j);
				hourseIntoDiv();
			}
		}
	} 
});

//�ж��Ƿ��Ѿ���·����
function hasNoRoad()
{
	for(var i=0;i<ROW;i++)
	{
		for(var j=0;j<COL;j++)
		{
			if(document.getElementById("div_"+i+"_"+j).style.backgroundColor=="pink")
			{
				return true;
			}
		}
	}
	return false;
} 
